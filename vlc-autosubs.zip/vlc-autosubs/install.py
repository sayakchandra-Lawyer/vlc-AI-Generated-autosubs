#!/usr/bin/env python3
"""Install AutoSubs (automatic English subtitles) into VLC.

    python3 install.py                 install + turn on automatic mode
    python3 install.py --manual-only   install, but only the menu extension
    python3 install.py --model medium  pick a model (writes autosubs.conf)
    python3 install.py --uninstall     remove everything again

Close VLC before running it. Works on Windows, macOS and Linux.
"""

import argparse
import os
import platform
import re
import shutil
import subprocess
import sys
import venv

HERE = os.path.dirname(os.path.abspath(__file__))
SYSTEM = platform.system()


def vlc_user_dir():
    home = os.path.expanduser("~")
    if SYSTEM == "Windows":
        return os.path.join(os.environ["APPDATA"], "vlc")
    if SYSTEM == "Darwin":
        return os.path.join(home, "Library", "Application Support", "org.videolan.vlc")
    data = os.environ.get("XDG_DATA_HOME") or os.path.join(home, ".local", "share")
    return os.path.join(data, "vlc")


def vlcrc_path():
    home = os.path.expanduser("~")
    if SYSTEM == "Windows":
        return os.path.join(os.environ["APPDATA"], "vlc", "vlcrc")
    if SYSTEM == "Darwin":
        return os.path.join(home, "Library", "Preferences", "org.videolan.vlc", "vlcrc")
    conf = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(conf, "vlc", "vlcrc")


FILES = [
    ("lua/modules/autosubs_core.lua", "lua/modules/autosubs_core.lua"),
    ("lua/intf/autosubs.lua", "lua/intf/autosubs.lua"),
    ("lua/extensions/autosubs_ext.lua", "lua/extensions/autosubs_ext.lua"),
    ("helper/vlc_autosubs.py", "autosubs/vlc_autosubs.py"),
]


# --------------------------------------------------------------------------
# vlcrc editing: extraintf (in [core]) gets "luaintf", lua-intf (in [lua])
# becomes "autosubs".
# --------------------------------------------------------------------------

def _set_option(lines, section, key, transform):
    pat = re.compile(r"^#?\s*" + re.escape(key) + r"\s*=(.*)$")
    for i, line in enumerate(lines):
        m = pat.match(line.rstrip("\r\n"))
        if m:
            current = "" if line.startswith("#") else m.group(1).strip()
            new = transform(current)
            lines[i] = f"{key}={new}\n" if new is not None else f"#{key}=\n"
            return
    new = transform("")
    if new is None:
        return
    header = f"[{section}]"
    for i, line in enumerate(lines):
        if line.strip().startswith(header):
            lines.insert(i + 1, f"{key}={new}\n")
            return
    lines.append(f"\n{header}\n{key}={new}\n")


def edit_vlcrc(enable):
    path = vlcrc_path()
    lines = []
    if os.path.exists(path):
        with open(path, encoding="utf-8", errors="surrogateescape") as f:
            lines = f.readlines()
        backup = path + ".autosubs-backup"
        if enable and not os.path.exists(backup):
            shutil.copy2(path, backup)
    elif not enable:
        return

    def extraintf(cur):
        mods = [m for m in cur.split(":") if m]
        if enable and "luaintf" not in mods:
            mods.append("luaintf")
        if not enable:
            mods = [m for m in mods if m != "luaintf"]
        return ":".join(mods) or None

    def lua_intf(cur):
        if enable:
            return "autosubs"
        return None if cur == "autosubs" else (cur or None)

    _set_option(lines, "core", "extraintf", extraintf)
    _set_option(lines, "lua", "lua-intf", lua_intf)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", errors="surrogateescape") as f:
        f.writelines(lines)
    print(("enabled" if enable else "disabled") + f" automatic mode in {path}")


# --------------------------------------------------------------------------

def make_venv(root, python_packages):
    env_dir = os.path.join(root, "venv")
    print(f"creating Python environment in {env_dir} (this downloads ~200 MB)…")
    venv.EnvBuilder(with_pip=True, clear=False).create(env_dir)
    py = os.path.join(env_dir, "Scripts", "python.exe") if SYSTEM == "Windows" \
        else os.path.join(env_dir, "bin", "python")
    subprocess.check_call([py, "-m", "pip", "install", "--upgrade", "pip"])
    subprocess.check_call([py, "-m", "pip", "install", "--upgrade", *python_packages])
    return py


def download_model(py, model):
    print(f"downloading Whisper model '{model}'…")
    subprocess.check_call([py, "-c",
        "import sys; from faster_whisper import WhisperModel; "
        "WhisperModel(sys.argv[1], device='cpu', compute_type='int8')", model])


def install(args):
    user_dir = vlc_user_dir()
    root = os.path.join(user_dir, "autosubs")
    for src, dst in FILES:
        dst = os.path.join(user_dir, *dst.split("/"))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(os.path.join(HERE, *src.split("/")), dst)
        print(f"installed {dst}")
    os.makedirs(os.path.join(root, "jobs"), exist_ok=True)

    conf = os.path.join(root, "autosubs.conf")
    settings = {}
    if os.path.exists(conf):
        with open(conf, encoding="utf-8") as f:
            for line in f:
                if "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    settings[k.strip()] = v.strip()
    if args.model:
        settings["model"] = args.model
    if args.python:
        settings["python"] = args.python
    with open(conf, "w", encoding="utf-8") as f:
        f.write("# AutoSubs settings — see README.md. Restart VLC after editing.\n")
        for k, v in settings.items():
            f.write(f"{k}={v}\n")

    if args.python:
        py = args.python
    else:
        py = make_venv(root, ["faster-whisper"])
    if args.download_model:
        download_model(py, args.download_model)

    if not args.manual_only:
        edit_vlcrc(True)
    print("\nDone. Start VLC and play a video" +
          ("" if args.manual_only else " — English subtitles appear automatically.") +
          "\nManual mode: View > Auto English Subtitles (macOS: VLC > Extensions).")


def uninstall():
    user_dir = vlc_user_dir()
    for _, dst in FILES:
        path = os.path.join(user_dir, *dst.split("/"))
        if os.path.exists(path):
            os.remove(path)
            print(f"removed {path}")
    root = os.path.join(user_dir, "autosubs")
    if os.path.isdir(root):
        shutil.rmtree(root)
        print(f"removed {root}")
    edit_vlcrc(False)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--uninstall", action="store_true")
    ap.add_argument("--manual-only", action="store_true",
                    help="don't turn on automatic mode, only install the extension")
    ap.add_argument("--model", help="tiny|base|small|medium|large-v3 (default: auto)")
    ap.add_argument("--download-model", metavar="MODEL",
                    help="pre-download a model now instead of on first use")
    ap.add_argument("--python", help="use this Python (with faster-whisper "
                    "installed) instead of creating a virtualenv")
    args = ap.parse_args()
    if args.uninstall:
        uninstall()
    else:
        install(args)


if __name__ == "__main__":
    main()
